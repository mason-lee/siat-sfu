<?php 
	$fullname = $_GET['fullname'];
	$username = $_GET['username'];
	$email = $_GET['email'];
	$school = $_GET['school'];
	$website = $_GET['website'];

	$title_name = "Mason | Members";
	$section = "members";

	include('includes/header.php');
?>
	<?php echo 
	"<div class='form-container'>
		<div class='container'>	
		<div class='center-stuff'>
			<h2>
				More information about <span class='underline'>$fullname</span>
			</h2>
		</div>
		
		<table class='table-padding'>
			<tr>
				<th>Name</th>
				<th>Username</th>
				<th>Email</th>
				<th>Secondary School</th>
				<th>Website</th>
			</tr>
			<tr>
				<td>$fullname</td>
				<td>$username</td>
				<td>$email</td>
				<td><a class=\"underline\" href=\"school_members.php?school=$school\">$school</a></td>
				<td>$website</td>
			</tr>
		</table>
		</div>
	</div>";
	?>

<?php include('includes/footer.php') ?>