<?php 
	$title_name = "Mason | Members";
	$section = "members";
	include('includes/header.php'); 
?>

	<div class="form-container">
		<div class="container">
			<h1>
				Registered Members
				<!-- <a href="member_detail.php?fullname=TEST">Test</a> -->
			</h1>
			<?php 
				
				$logFile = 'form.txt';
				$lines = file($logFile); // Get each line of the file and store it as an array
				$table = '<table><tr><th>Name</th><th>Email</th><th>Secondary School</th></tr>'; // A variable $table, we'll use this to store our table and output it later !
				
				foreach($lines as $line){ // We are going to loop through each line
				    // list($lastname, $firstname, $email, $school) = explode(',', $line);
				    $data = explode('|', $line);
				
				    // What explode basically does is it takes a delimiter, and a string. It will generate an array depending on those two parameters
				    // To explain this I'll provide an example : $array = explode('.', 'a.b.c.d');
				    // $array will now contain array('a', 'b', 'c', 'd');
				    // We use list() to give them kind of a "name"
				    // So when we use list($date, $time, $ip, $domain) = explode('.', 'a.b.c.d');
				    // $date will be 'a', $time will be 'b', $ip will be 'c' and $domain will be 'd'
				    // We could also do it this way:
				    // $data = explode(' - ', $line);
				    // $table .= '<tr><td>'.$data[0].'</td><td>'.$data[1].'</td><td>'.$data[2].'</td><td>'.$data[3].'</td></tr>';
				    // But the list() technique is much more readable in a way   
					$fullname = $data[0];
					$username = $data[1];
					$email = $data[3];
					$school = $data[4];
					$website = $data[5];
					$table .= "<tr>
								<td><a class=\"underline\" href=\"member_detail.php?fullname=$fullname&username=$username&email=$email&school=$school&website=$website\">$fullname</a></td>
								<td>$email</td>
								<td><a class=\"underline\" href=\"school_members.php?school=$school\">$school</a></td>
							</tr>";
					//$table .= '<tr><td><a href="member_detail.php?fullname=testing">'.$fullname.'</a></td><td>'.$email.'</td><td>'.$school.'</td></tr>';
					// $table .= '<tr><td><a href="#">'.$data[0].'</a></td><td>'.$data[3].'</td><td>'.$data[4].'</td></tr>';
				}
				$table .= '</table>';
				echo $table;
			?>
		</div>
	</div>

<?php include('includes/footer.php') ?>




