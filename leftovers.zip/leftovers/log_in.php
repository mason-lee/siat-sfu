<?php 
// include('includes/header.php');
?>

<!-- <div class="form-container">
    <div class="login-box">
        <h2>
            SIAT wants to provide better information to 
            potential students and their parents.<br>
            Please be an ambassador for SIAT program!
        </h2>
        <form action="validating_login.php" method="POST">
            <div class="form-row">
                <div class="form-row-body">
                    <label>Username</label>
                    <input type="text" name="username" size="50" placeholder="username"/>
                </div>
            </div>
            <div class="form-row">
                <div class="form-row-body">
                    <label>Password</label>
                    <input type="text" name="password" size="50" placeholder="password" />
                </div>
            </div>
            <div class="form-row">
                <div class="form-row-body">
                    <input type="submit" value="Log In"/>
                </div>
            </div>
        </form>
    </div>
</div>         -->




<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8" >
    </head>
    <body>
        <form action="validating_login.php" method="POST">
            <p><label>ID</label><input type="text" name="id" /></p>
            <p><label>PASS</label><input type="text" name="pwd" /></p>
 
        <input type="submit" />
        </form>
    </body>
</html>
</html>