<?php
session_start();
$id = 'egoing';
$pwd = 'codingeverybody';
if(!empty($_POST['id']) && !empty($_POST['pwd'])){
    if($_POST['id'] == $id && $_POST['pwd'] == $pwd){
        $_SESSION['is_login'] = true;
        $_SESSION['nickname'] = 'Egoing';
        header('Location: ./user_logged_in.php');
        exit;
    }
}
echo 'Fail loging';
?>