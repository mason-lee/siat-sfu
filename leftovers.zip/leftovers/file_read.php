<?php

	$file = 'test.txt';
	if($handle = fopen($file, 'r')) { // Open file in read mode
		$content = fread($handle, 6); // set the number of characters to read
		fclose($handle);
	}
	
	// Print out the content without formating. Does not recognize new lines
	echo $content;
	echo "<br />";
	// nl2br converts new line character to <br/> tag
	echo nl2br($content);
	echo "<hr />";

	// use filesize() to read the whole file	
	if($handle = fopen($file, 'r')) {  // read
	$content = fread($handle, filesize($file));
	fclose($handle);
	}

	echo nl2br($content);
	echo "<hr />";

	// file_get_contents(): shortcut for fopen/fread/fclose
	// Read the whole content
	$content = file_get_contents($file);
	echo $content;
	echo "<hr/>";


	// Read line by line and append to $content	
	$content = "";
	if($handle = fopen($file, 'r')) {  // read
		// Read the content until you reach the end of file - feof
		while(!feof($handle)) {
			// read one line in each iteration - fgets
			$content .= fgets($handle);
		}
	fclose($handle);
	}

	echo $content;
	echo "<hr/>";
	
	// additional, how to split string
	// split string using separator
	$data = explode(" | ", "Dr. Gregory House, M.D. | house@example.com | This is my description");	
	
	// print name
	echo $data[0];
	// print email
	echo $data[1];
	// print description
	echo $data[2];
?>

